library(stylo)
CORPUS_DIR <- "corpus"

timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S") # used for file names

# List of all analysis types to test
analysis_types <- c("CA", "BCT", "PCV", "MDS")  # PCR excluded as it's less commonly used

# List of all distance measures to test
distance_measures <- c("delta", "argamon", "eder", "simple", "canberra", 
                       "manhattan", "euclidean", "cosine", "wurzburg", "minmax")

# # Do not use the following when doing word n-grams!!!
# # Create a temp directory with space-free versions
# dir.create("corpus_nospace", showWarnings = FALSE)
# corpus_files <- list.files("corpus", full.names = TRUE)
# for (file in corpus_files) {
#   text <- readLines(file, encoding = "UTF-8")
#   text <- gsub(" ", "", text)
#   new_file <- file.path("corpus_nospace", basename(file))
#   writeLines(text, new_file)
# }

# Outer loop through all analysis types
for (analysis_type in analysis_types) {
  
  cat("\n########################################\n")
  cat("### ANALYSIS TYPE:", analysis_type, "###\n")
  cat("########################################\n")
  
  # PCV doesn't use distance measures, so only run it once
  if (analysis_type == "PCV") {
    cat("\n========================================\n")
    cat("Processing: PCV (distance measure not applicable)\n")
    cat("========================================\n")
    
    # Create filename for PCV without distance measure
    filename <- paste0("clusters_W1_50-200_", analysis_type, "_", timestamp)
    
    # Run stylo for PCV (distance measure doesn't matter, using delta as placeholder)
    results <- stylo(gui = FALSE,
                     corpus.dir = "corpus",
                     analyzed.features = "w",
                     ngram.size = 1, # 3 is typically for char n-grams, 1 is typically for mfw
                     preserve.case = FALSE,
                     distance.measure = "delta", # Placeholder - not used by PCV
                     analysis.type = analysis_type,
                     encoding = "UTF-8",
                     mfw.min = 100, # changing these numbers have significant effects in outcome
                     mfw.max = 500, # this
                     mfw.incr = 100,# and this
                     culling.min = 0,
                     culling.max = 0,
                     culling.incr = 20,
                     mfw.list.cutoff = 20000,
                     consensus.strength = 0.5,
                     sampling = "no.sampling",
                     sample.size = 10000,
                     number.of.samples = 1,
                     sampling.with.replacement = FALSE,
                     display.on.screen = FALSE,  # Changed to FALSE to avoid opening many windows
                     write.pdf.file = TRUE,
                     write.jpg.file = FALSE,
                     write.svg.file = FALSE,
                     write.png.file = FALSE,
                     plot.custom.height = 20,
                     plot.custom.width = 20,
                     plot.font.size = 10,
                     plot.line.thickness = 1,
                     plot.options.reset = FALSE,
                     custom.graph.title = "PCV (Principal Components)",
                     custom.graph.filename = filename,
                     text.id.on.graphs = "both",
                     colors.on.graphs = "colors",
                     titles.on.graphs = TRUE,
                     label.offset = 0)
    
    cat("Completed: PCV\n")
    
  } else {
    # For CA, BCT, and MDS: loop through all distance measures
    for (dist_measure in distance_measures) {
      
      cat("\n========================================\n")
      cat("Processing:", analysis_type, "with", dist_measure, "\n")
      cat("========================================\n")
      
      # Create filename with analysis type, distance measure, and timestamp
      # I'm adding C3_500 etc., for character 3-grams 500 samples, etc.
      filename <- paste0("clusters_W1_50-200_", analysis_type, "_", dist_measure, "_", timestamp)
      
      # Run stylo with current analysis type and distance measure
      results <- stylo(gui = FALSE,
                       # corpus.dir = "corpus_nospace",	# this works only for character n-grams! experimented to see if 
                       # there are any differences, but there does not seem to be much difference.
                       corpus.dir = "corpus",
                       # analyzed.features = "c", 	# testing char n-grams and mfw n-grams have enormous effects in outcome
                       analyzed.features = "w",
                       ngram.size = 1, # 3 is typically for char n-grams, 1 is typically for mfw
                       preserve.case = FALSE,
                       distance.measure = dist_measure, # iterating through all possible measurements
                       analysis.type = analysis_type, # iterating through all possible analysis types
                       encoding = "UTF-8",
                       # mfw.min = 1000, # These numbers are good with character n-grams
                       # mfw.max = 10000,
                       # mfw.incr = 100,
                       mfw.min = 50, # changing these numbers have significant effects in outcome
                       mfw.max = 200, # this
                       mfw.incr = 50,# and this
                       culling.min = 50,
                       culling.max = 50,
                       culling.incr = 20,
                       mfw.list.cutoff = 20000,
                       consensus.strength = 0.5,
                       sampling = "no.sampling",
                       sample.size = 10000,
                       number.of.samples = 1,
                       sampling.with.replacement = FALSE,
                       display.on.screen = FALSE,  # Changed to FALSE to avoid opening many windows
                       write.pdf.file = TRUE,
                       write.jpg.file = FALSE,
                       write.svg.file = FALSE,
                       write.png.file = FALSE,
                       plot.custom.height = 20,
                       plot.custom.width = 20,
                       plot.font.size = 10,
                       plot.line.thickness = 1,
                       plot.options.reset = FALSE,
                       custom.graph.title = paste(analysis_type, "- Distance:", dist_measure),
                       custom.graph.filename = filename,
                       text.id.on.graphs = "both",
                       colors.on.graphs = "colors",
                       titles.on.graphs = TRUE,
                       label.offset = 0)
      
      cat("Completed:", analysis_type, "with", dist_measure, "\n")
    }
  }
  
  cat("\n########################################\n")
  cat("### Completed all distances for", analysis_type, "###\n")
  cat("########################################\n")
}

cat("\n========================================\n")
cat("ALL ANALYSES COMPLETE!\n")
# Calculate total: CA (10) + BCT (10) + PCV (1) + MDS (10) = 31
cat("Total PDFs created: 31 (PCV runs only once since distance doesn't affect it)\n")
cat("========================================\n")
