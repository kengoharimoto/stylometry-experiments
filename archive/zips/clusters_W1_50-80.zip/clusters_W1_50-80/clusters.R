library(stylo)
CORPUS_DIR <- "corpus"

timestamp <- format(Sys.time(), "%Y%m%d_%H%M%S") # used for file names

# ================================================
# SHARED STYLO PARAMETERS - DEFINED ONCE
# ================================================
# These parameters are used for ALL stylo() calls
# to ensure consistency across all analysis types

ANALYZED_FEATURES <- "w"      # "w" for words, "c" for characters
NGRAM_SIZE <- 1               # 1 for unigrams, 2 for bigrams, 3 for trigrams
PRESERVE_CASE <- FALSE
ENCODING <- "UTF-8"

# MFW settings
MFW_MIN <- 50
MFW_MAX <- 80
MFW_INCR <- 10

# Culling settings
CULLING_MIN <- 75
CULLING_MAX <- 75
CULLING_INCR <- 20

# Other settings
MFW_LIST_CUTOFF <- 20000
CONSENSUS_STRENGTH <- 0.5
SAMPLING <- "no.sampling"
SAMPLE_SIZE <- 10000
NUMBER_OF_SAMPLES <- 1
SAMPLING_WITH_REPLACEMENT <- FALSE

# Display and output settings
DISPLAY_ON_SCREEN <- FALSE
WRITE_PDF_FILE <- TRUE
WRITE_JPG_FILE <- FALSE
WRITE_SVG_FILE <- FALSE
WRITE_PNG_FILE <- FALSE
PLOT_CUSTOM_HEIGHT <- 20
PLOT_CUSTOM_WIDTH <- 20
PLOT_FONT_SIZE <- 10
PLOT_LINE_THICKNESS <- 1
PLOT_OPTIONS_RESET <- FALSE
TEXT_ID_ON_GRAPHS <- "both"
COLORS_ON_GRAPHS <- "colors"
TITLES_ON_GRAPHS <- TRUE
LABEL_OFFSET <- 0

# Save options
SAVE_DISTANCE_TABLES <- TRUE
SAVE_ANALYZED_FEATURES <- TRUE
SAVE_ANALYZED_FREQS <- TRUE

# ================================================
# ANALYSIS CONFIGURATION
# ================================================

# List of all analysis types to test
analysis_types <- c("CA", "BCT", "PCV", "MDS")  # PCR excluded as it's less commonly used

# List of all distance measures to test
distance_measures <- c("delta", "argamon", "eder", "simple", "canberra", 
                       "manhattan", "euclidean", "cosine", "wurzburg", "minmax")

# ================================================
# MAIN ANALYSIS LOOP
# ================================================

# Outer loop through all analysis types
for (analysis_type in analysis_types) {
  
  cat("\n########################################\n")
  cat("### ANALYSIS TYPE:", analysis_type, "###\n")
  cat("########################################\n")
  
  # PCV doesn't use distance measures, so only run it once
  if (analysis_type == "PCV") {
    cat("\n========================================\n")
    cat("Processing: PCV (distance measure not applicable)\n")
    cat("========================================\n")
    
    # Create filename for PCV without distance measure
    filename <- paste0("clusters_W1_", MFW_MIN, "-", MFW_MAX, "_", analysis_type, "_", timestamp)
    
    # Run stylo for PCV (distance measure doesn't matter, using delta as placeholder)
    results <- stylo(gui = FALSE,
                     corpus.dir = CORPUS_DIR,
                     analyzed.features = ANALYZED_FEATURES,
                     ngram.size = NGRAM_SIZE,
                     preserve.case = PRESERVE_CASE,
                     distance.measure = "delta", # Placeholder - not used by PCV
                     analysis.type = analysis_type,
                     encoding = ENCODING,
                     mfw.min = MFW_MIN,
                     mfw.max = MFW_MAX,
                     mfw.incr = MFW_INCR,
                     culling.min = CULLING_MIN,
                     culling.max = CULLING_MAX,
                     culling.incr = CULLING_INCR,
                     mfw.list.cutoff = MFW_LIST_CUTOFF,
                     consensus.strength = CONSENSUS_STRENGTH,
                     sampling = SAMPLING,
                     sample.size = SAMPLE_SIZE,
                     number.of.samples = NUMBER_OF_SAMPLES,
                     sampling.with.replacement = SAMPLING_WITH_REPLACEMENT,
                     display.on.screen = DISPLAY_ON_SCREEN,
                     write.pdf.file = WRITE_PDF_FILE,
                     write.jpg.file = WRITE_JPG_FILE,
                     write.svg.file = WRITE_SVG_FILE,
                     write.png.file = WRITE_PNG_FILE,
                     plot.custom.height = PLOT_CUSTOM_HEIGHT,
                     plot.custom.width = PLOT_CUSTOM_WIDTH,
                     plot.font.size = PLOT_FONT_SIZE,
                     plot.line.thickness = PLOT_LINE_THICKNESS,
                     plot.options.reset = PLOT_OPTIONS_RESET,
                     custom.graph.title = "PCV (Principal Components)",
                     custom.graph.filename = filename,
                     text.id.on.graphs = TEXT_ID_ON_GRAPHS,
                     colors.on.graphs = COLORS_ON_GRAPHS,
                     titles.on.graphs = TITLES_ON_GRAPHS,
                     label.offset = LABEL_OFFSET,
                     save.distance.tables = FALSE,  # PCV doesn't use distances
                     save.analyzed.features = SAVE_ANALYZED_FEATURES,
                     save.analyzed.freqs = SAVE_ANALYZED_FREQS)
    
    cat("Completed: PCV\n")
    
  } else {
    # For CA, BCT, and MDS: loop through all distance measures
    for (dist_measure in distance_measures) {
      
      cat("\n========================================\n")
      cat("Processing:", analysis_type, "with", dist_measure, "\n")
      cat("========================================\n")
      
      # Create filename with analysis type, distance measure, and timestamp
      filename <- paste0("clusters_W1_", MFW_MIN, "-", MFW_MAX, "_", 
                        analysis_type, "_", dist_measure, "_", timestamp)
      
      # Run stylo with current analysis type and distance measure
      results <- stylo(gui = FALSE,
                       corpus.dir = CORPUS_DIR,
                       analyzed.features = ANALYZED_FEATURES,
                       ngram.size = NGRAM_SIZE,
                       preserve.case = PRESERVE_CASE,
                       distance.measure = dist_measure,
                       analysis.type = analysis_type,
                       encoding = ENCODING,
                       mfw.min = MFW_MIN,
                       mfw.max = MFW_MAX,
                       mfw.incr = MFW_INCR,
                       culling.min = CULLING_MIN,
                       culling.max = CULLING_MAX,
                       culling.incr = CULLING_INCR,
                       mfw.list.cutoff = MFW_LIST_CUTOFF,
                       consensus.strength = CONSENSUS_STRENGTH,
                       sampling = SAMPLING,
                       sample.size = SAMPLE_SIZE,
                       number.of.samples = NUMBER_OF_SAMPLES,
                       sampling.with.replacement = SAMPLING_WITH_REPLACEMENT,
                       display.on.screen = DISPLAY_ON_SCREEN,
                       write.pdf.file = WRITE_PDF_FILE,
                       write.jpg.file = WRITE_JPG_FILE,
                       write.svg.file = WRITE_SVG_FILE,
                       write.png.file = WRITE_PNG_FILE,
                       plot.custom.height = PLOT_CUSTOM_HEIGHT,
                       plot.custom.width = PLOT_CUSTOM_WIDTH,
                       plot.font.size = PLOT_FONT_SIZE,
                       plot.line.thickness = PLOT_LINE_THICKNESS,
                       plot.options.reset = PLOT_OPTIONS_RESET,
                       custom.graph.title = paste(analysis_type, "- Distance:", dist_measure),
                       custom.graph.filename = filename,
                       text.id.on.graphs = TEXT_ID_ON_GRAPHS,
                       colors.on.graphs = COLORS_ON_GRAPHS,
                       titles.on.graphs = TITLES_ON_GRAPHS,
                       label.offset = LABEL_OFFSET,
                       save.distance.tables = SAVE_DISTANCE_TABLES,
                       save.analyzed.features = SAVE_ANALYZED_FEATURES,
                       save.analyzed.freqs = SAVE_ANALYZED_FREQS)
      
      cat("Completed:", analysis_type, "with", dist_measure, "\n")
    }
  }
  
  cat("\n########################################\n")
  cat("### Completed all distances for", analysis_type, "###\n")
  cat("########################################\n")
}

cat("\n========================================\n")
cat("ALL ANALYSES COMPLETE!\n")
cat("Total PDFs created: 31 (PCV runs only once since distance doesn't affect it)\n")
cat("========================================\n")

# Print summary of settings used
cat("\n========================================\n")
cat("ANALYSIS SETTINGS SUMMARY:\n")
cat("========================================\n")
cat("Feature type:", ANALYZED_FEATURES, "\n")
cat("N-gram size:", NGRAM_SIZE, "\n")
cat("MFW range:", MFW_MIN, "-", MFW_MAX, "by", MFW_INCR, "\n")
cat("Culling:", CULLING_MIN, "%\n")
cat("Iterations per analysis:", (MFW_MAX - MFW_MIN) / MFW_INCR + 1, "\n")
cat("Distance measures:", length(distance_measures), "\n")
cat("Analysis types:", length(analysis_types), "\n")
cat("Save distance tables:", SAVE_DISTANCE_TABLES, "\n")
cat("Save analyzed features:", SAVE_ANALYZED_FEATURES, "\n")
cat("Save frequency tables:", SAVE_ANALYZED_FREQS, "\n")
cat("========================================\n")